﻿using System;

namespace Razakhan_Mohammad_Conditionals_Assignment
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			/*
			 * Mohammad Raza Khan
			 * November 13, 2015
			 * Section # 02
			 * Conditional Assignment
			*/

			//Age Verification Calculator

			//verifies age by date of birth.
			//Decides weather a person is eligible to enter a concert in a bar

			//Asks user for a name
			Console.WriteLine ("Please type your name and hit enter.");

			//Stores the user response
			string userName = Console.ReadLine ();

			//Loop statement for the user to enter their name, and not leave it blank
			while (string.IsNullOrWhiteSpace (userName)) {

				//Prompts the user to enter name again
				Console.WriteLine ("Please don't leave this blank. Type your name, and hit enter.");

				//Saves the user's name
				userName = Console.ReadLine ();
				
			}

			//Greets the user with a name, and states the task
			Console.WriteLine ("Hello, " + userName + "! Lets find out if you're eligible to enter the concert, and be able to purchase drinks.");

			//asks the user to enter the month of the birth
			Console.WriteLine (userName + ", please type your month of birth, then hit enter.");

			//Creates a string for the month of birth
			string monthString = Console.ReadLine ();

			//variable for the convertion
			int month;

			//Loop statement for month
			while (!int.TryParse (monthString, out month)) {

				//Warns the user
				Console.WriteLine ("Please enter the month in numeral.");

				//Stores the user response
				monthString = Console.ReadLine ();


			}

			//Asks the user for the Day of birth
			Console.WriteLine (userName + ", please type the day of your birth, then hit enter.");

			//String for the user's day of birth
			string dayString = Console.ReadLine ();

			//Variable for converstion
			int day;

			//Loop statement for day
			while (!int.TryParse (dayString, out day)) {

				//Prompts the user to enter numeral
				Console.WriteLine ("Please enter a numeral.");

				//Recatches the user response
				dayString = Console.ReadLine ();
				
			}

			//Asks the user to enter the year of birth
			Console.WriteLine (userName + ", please type the year of birth, then hit enter.");

			//String for the year of birth
			string yearString = Console.ReadLine ();

			//variable for converstion
			int year;

			//Loop statement for the year of birth
			while (!int.TryParse (yearString, out year)) {

				//informs the user to enter a numeral
				Console.WriteLine ("Please enter the year in numeral.");

				//Restores the users response
				yearString = Console.ReadLine ();

			}

			//Creates birthdate variable
			DateTime birthdate = new DateTime (year, month, day);

			//Now time variable been created
			DateTime today = DateTime.Today;

			//Age calculation
			int age = today.Year - birthdate.Year;

			//Inverse the age
			if (birthdate > today.AddYears(-age)) age--;
		
			//If statement for entering the bar
			if (age >= 21) {

				//The user is old enough to enter the bar.
				Console.WriteLine ("Congratulation " + userName + "! you're "+age+" years old. You may get in the concert, and get a wrist band to drink.\r\nEnjoy the evening " + userName + "!");

				//Else if statement for the user to be over 18, but not 21
			} else if (age >= 18 && age < 21) {

				//Prompts the user if the user is over the age of 18
				Console.WriteLine (userName+"! you're "+age+" yours old. You may enter the concert, but you can't purchase any alcohol.\r\nEnjoy the evening "+userName+"!");

				//Else statement for a minor user
			} else {

				//Prompts the minor user 
				Console.WriteLine ("We're sorry "+userName+" you're a minor. You can't get in the concert. You're only "+age+" years old.\r\nPlease return home.");
			}
		
			/*
			 * I entere my birthday, which is 12/31/1994, and I got accurate result. I am 20 years old.
			 * I entered 11/13/1994, which is exactly the day for one to turn 21, and I got 21 as my result.
			 * I also tried entering the date to run the else if statement. I entered 11/10/1997, and I was able to run it. I got 17 as the age.
			 * I ran the else statement by entering 11/10/1999, and I got 16 as the age.
			*/

		}

	}
}
