﻿using System;

namespace ExpressionWorksheet
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			/*
			 * Mohammad Raza Khan
			 * Section 02
			 * November 4th 2015
			 * Expression Worksheet
			*/

			//Find the area of a rectangle given the width and height of the rectangle

			//Declare the variable for givens
			double width = 65;
			double height = 35;

			//Declare the variable for the rectangle
			//area = width*height
			double arearect = width * height;


			//Final out put
			Console.WriteLine ("The area of a rectangle is " + arearect);

			//End of area rectangle


			/*
			 * Dogs age 7 times faster than humans so a dog that is 1 year old in human years is 7 years old in “dog years.” 
			 * Calculate how old Sparky the pit bull is in dog years based on his actual age.
			*/

			//Given the variable to the dog and the human
			//listens to the users answers
			Console.WriteLine ("Please enter the dogs age then press enter");
			string dogsage = Console.ReadLine ();


			//conversts dogsagestring to a number
			int ageNumb = int.Parse (dogsage);

			int human = 7;

			//age=dog*human
			int sparkyage = ageNumb * human;

			//final print out
			Console.WriteLine ("Sparky is " + ageNumb + " human years old which is " + sparkyage + " in dog years");

			//End of Dogs Age


			/*
			 * A bunch of students are having a party and somebody ordered pizza. 
			 * Create an expression that calculates how much pizza each partygoer will get at the party. 
			 * Assume all pizzas have the same number of slices and that the person dividing the pizza is really precise.
			 * This can be a decimal, like 3.52 slices, etc.
			*/

			//prompts the user to enter the number of people
			//catches the answer from the user
			Console.WriteLine ("Please type the number of people then press enter");
			string numbPeople = Console.ReadLine ();

			//converts string to number
			int peopleNumb = int.Parse (numbPeople);

			//prompts the user for the number of pizzas
			Console.WriteLine ("Please type the number of pizza then press enter");
			string numbPizza = Console.ReadLine ();

			//converts the string of pizza to number
			int pizzaNum = int.Parse (numbPizza);

			//calculates the number of pizza per person
			int numPpp = numbPizza / numbPeople;

			//converts the string to number
			int pizPp = int.Parse (numPpp);

			//Declares the size of the slices
			decimal sliceSize = 3.52;	

			//Divides the pizza into slices
			int sliceAte = numPpp / sliceSize;

			//Final print out
			Console.WriteLine ("Each person ate "+sliceAte+" slices of pizza at the party.");

			//End of Slices of Pizzas
	


		}
		
	}
}
