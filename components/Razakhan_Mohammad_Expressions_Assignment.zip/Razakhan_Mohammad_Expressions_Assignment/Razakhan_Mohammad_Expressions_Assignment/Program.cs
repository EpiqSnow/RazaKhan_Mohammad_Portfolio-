﻿using System;

namespace Razakhan_Mohammad_Expressions_Assignment
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			/*
			 * Mohammad Raza Khan
			 * November 4th, 2015
			 * Section 02
			 * Expressions Assignment
			*/

			//Tip Calculator
			//Calculates the total tip
			//Distributes the tip and the total bill amount among people

			//Greets the user
			Console.WriteLine ("Hello! \r\nI will help you find the right amount to tip and the total amount per person.");


			//Prompts user for the total amount of the bill
			Console.WriteLine ("Please type the total amount of the bill then press enter");

			//Catches the users answer
			String billAmount = Console.ReadLine ();

			//Converts string to int
			double billTotal = double.Parse (billAmount);


			//Prompts user for the percentage
			Console.WriteLine ("Please type the percentage you want to tip and press enter");

			//Catches the users answer
			string Percentage = Console.ReadLine ();

			//Converts string to int
			double Percent = double.Parse (Percentage);


			//Prompts user for the total number of people
			Console.WriteLine ("Please enter the number of people then press enter");

			//Catches the users answer
			string numbPeople = Console.ReadLine ();

			//Converts string to int
			double peopleTotal = double.Parse (numbPeople);


			//Multiplies amount of bill by the percentage
			double billPercent = (billTotal*Percent);

			//Creates a double to move the decimal
			double deciMove = 100.0;

			//Moves the decimal to get the tip amount
			double totalTip = (billPercent / deciMove);

			//Distributes the tip among the number of people
			double tipSplit = (totalTip / peopleTotal);

			//Divides the billTotal by the numbPeople
			double amongTotal = (billTotal/peopleTotal);

			//Adds the billTotal with tip
			double billAndTip = (amongTotal+tipSplit);

			//Creates an Array to store the totals
			double [] finalTotals = new double[3];

			//Assigns the values to the Arrays
			finalTotals[0] = billAndTip;
			finalTotals [1] = tipSplit;
			finalTotals [2] = totalTip;


			//Prints out the final total
			Console.WriteLine ("The tip for the total amount is $"+finalTotals[2]);
			Console.WriteLine ("However, when the tip is split among the number of the people then the total of the tip would be $" +finalTotals[1]);
			Console.WriteLine ("The total amount would be per person $"+finalTotals[0]);

			//End of tip Calculator




		}
	}
}
