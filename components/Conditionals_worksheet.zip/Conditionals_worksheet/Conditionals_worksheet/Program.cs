﻿using System;

namespace Conditionals_worksheet
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			/*
			 * Mohammad Raza Khan
			 * November 09, 2015
			 * Conditional Worksheet
			 * Section #02
			*/


			//Stuff Your Face

			//Create a variable

			//Prompts the user to enter the weight
			Console.WriteLine ("Please enter the competitor's weight and hit enter.");

			//Catches the users answer
			string weightString = Console.ReadLine();

			//Converts the string to int
			int weight = int.Parse (weightString);

			//Create conditional to test weight
			if (weight >= 250) {
				Console.WriteLine ("The competitor qualifies for the heavyweight division.");
			} else {
				Console.WriteLine ("The competitor needs to gain some weight!");
			} 

			//End of stuff your face


			//Celsius to Fahrenheit converter
			/*Convert a temperature to either degrees Celsius or degrees Fahrenheit depending on what the user has entered. 
			 * If the user puts a “C” for the unit, the calculator should convert to Celsius. 
			 * If the user puts “F” for the unit, the calculator should convert to Fahrenheit.
			*/

			/*

			Given:

			Degrees (in F or C)
			Unit (a string holding an “F” or a “C”)

			Result:

			“The temperature is X degrees Celsius.” Or “The temperature is X degrees Fahrenheit.”

			Data Sets to Test: (Note that data sets are not the only numbers that should work with your code.)

			32F is 0C
			100C is 212F
			90F is 32.22C

			*/

			//Prompt the user to enter the temperature
			Console.WriteLine ("Please enter the temperature in celcius and hit enter.");

			//Catches the user answer
			string celiusTemp = Console.ReadLine();






		}
	}
}
